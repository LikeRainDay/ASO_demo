# Theos: *Unified cross-platform Makefile system.*

[![Travis Status](https://travis-ci.org/theos/theos.svg)](https://travis-ci.org/theos/theos)

Please note: Theos has undergone a number of changes recently. To learn more, visit [**the wiki**](https://github.com/theos/theos/wiki).

See [LICENSE.md](LICENSE.md) for licensing information.
