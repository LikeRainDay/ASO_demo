@interface CPBitmapStore : NSObject

- (void)purge;

@end
